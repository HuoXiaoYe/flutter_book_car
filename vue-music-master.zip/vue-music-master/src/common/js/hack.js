function noop() {

}

window.MessageChannel = noop
window.setImmediate = noop
